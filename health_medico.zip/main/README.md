# medical-assiatant-python-flask

# Prerequisite
1. Html/css/javascript
2. Basic python
3. Python flask frame work
4. My sql commands 
5. php Myadmin 


# About this project

1. This is a virtual Medical Assitant project were help for patient to get advice from doctor through online

2. patient side - Patient request to consult, ask query with doctor

3. Doctor side - patient request acceptance, Answer queries to patient

4. covid 19 updates till date (in graph format)




# Work Flow
1. Install python with any ide like pycharm, spyder, vs code etc.

2. Download this project

3. Make sure also you have mysql with server(php myadmin) installed like wampp, xammp etc for data base.

4. First to set the data base open your php my admin and create database with name medico and import and medico.sql file given in this project

5. Now change the app.config credentials with your mysql credentials i.e. give your mysql details in place of app.config['MYSQL_HOST']  in app.py file

6. Open your ide and open the downloaded project folder 

7. Now run the app.py file

8. In the compiler you will get the message like this. If not you have error in the code

Restarting with stat Debugger is active! Debugger PIN: 716-674-243 Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

9. On the clicking the url your website will be locally hosted in your web browser.

10. To locate to doctor login page type http://127.0.0.1:5000/doctor it will navigate

11. See the database doctor table to know about doctor credentials


demo video: https://www.youtube.com/watch?v=3G9Op0ckTi0

cloud deployement : https://virtual-medical12.herokuapp.com/  (you can view this project website by clicking this link) note : login credentials is same given in medico.sql file

